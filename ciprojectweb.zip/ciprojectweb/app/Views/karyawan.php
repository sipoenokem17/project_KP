       <?= $this->extend('layout'); ?>

       <?= $this->section('main-content'); ?>
       <!-- Page header -->
       <div class="page-header d-print-none">
           <div class="container-xl">
               <div class="row g-2 align-items-center">
                   <div class="col">
                       <h2 class="page-title">
                           Daftar Karyawan
                       </h2>
                   </div>
                   <!-- Page title actions -->
                   <div class="col-auto ms-auto d-print-none">
                       <div class="d-flex">
                           <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal-tambah">
                               <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                               <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                   <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                   <path d="M12 5l0 14" />
                                   <path d="M5 12l14 0" />
                               </svg>
                               Tambah
                           </a>
                       </div>
                   </div>
               </div>
           </div>
       </div>
       <!-- Page body -->
       <div class="page-body">
           <div class="container-xl">
               <div class="row row-cards">
                   <?php foreach ($karyawan as $k): ?>
                       <div class="col-md-6 col-lg-3">
                           <div class="card">
                               <div class="card-body p-4 text-center">
                                   <span class="avatar avatar-xl mb-3 rounded"><?= $k['inisial']; ?></span>
                                   <h3 class="m-0 mb-1"><a href="#" data-bs-toggle="modal" data-bs-target="#modal-simple"><?= $k['nama']; ?></a></h3>
                                   <div class="text-secondary"><?= $k['jabatan']; ?></div>
                               </div>
                               <div class="d-flex">
                                   <a href="#" class="card-btn btn btn-warning btn-icon btn-ubah" data-bs-toggle="modal" data-bs-target="#modal-edit"><!-- Download SVG icon from http://tabler-icons.io/i/mail -->
                                       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-edit">
                                           <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                           <path d="M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1" />
                                           <path d="M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415z" />
                                           <path d="M16 5l3 3" />
                                       </svg>
                                   </a>
                                   <a href="#" class="card-btn btn btn-danger btn-icon btn-hapus" data-bs-toggle="modal" data-bs-target="#modal-danger"><!-- Download SVG icon from http://tabler-icons.io/i/phone -->
                                       <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                           <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                           <path d="M4 7l16 0"></path>
                                           <path d="M10 11l0 6"></path>
                                           <path d="M14 11l0 6"></path>
                                           <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                                           <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                                       </svg>
                                   </a>
                               </div>
                           </div>
                       </div>
                   <?php endforeach; ?>
               </div>
           </div>
       </div>

       <!-- Modal Tambah -->
       <div class="modal modal-blur fade" id="modal-tambah" tabindex="-1" role="dialog" aria-hidden="true">
           <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
               <div class="modal-content">
                   <form class="mt-3" method="post" action="tambahData">
                       <div class="modal-body">
                           <div class="mb-3">
                               <label class="form-label">Nama</label>
                               <input type="text" class="form-control" name="nama" required>
                           </div>
                           <div class="row">
                               <div class="col-lg-4">
                                   <div class="mb-3">
                                       <label class="form-label">jabatan</label>
                                       <input type="text" class="form-control" name="jabatan" required>
                                   </div>
                               </div>
                               <div class="col-lg-4">
                                   <div>
                                       <label class="form-label">Gaji</label>
                                       <input type="number" class="form-control" name="gaji" required>
                                   </div>
                               </div>
                               <div class="col-lg-4">
                                   <div class="mb-3">
                                       <label class="form-label">Tanggal Masuk</label>
                                       <input type="date" class="form-control" name="tgl_masuk" required>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="modal-footer">
                           <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                               Cancel
                           </a>
                           <button href="#" type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                               <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                               <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                   <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                   <path d="M12 5l0 14" />
                                   <path d="M5 12l14 0" />
                               </svg>
                               Tambah
                           </button>
                       </div>
                   </form>
               </div>
           </div>
       </div>

       <!-- Modal Edit -->
       <div class="modal modal-blur fade" id="modal-edit" tabindex="-1" role="dialog" aria-hidden="true">
           <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
               <div class="modal-content">
                   <div class="modal-body">
                       <div class="mb-3">
                           <label class="form-label">Nama</label>
                           <input type="text" class="form-control" name="example-text-input">
                       </div>
                       <div class="row">
                           <div class="col-lg-4">
                               <div class="mb-3">
                                   <label class="form-label">jabatan</label>
                                   <input type="text" class="form-control">
                               </div>
                           </div>
                           <div class="col-lg-4">
                               <div>
                                   <label class="form-label">Gaji</label>
                                   <input type="number" class="form-control">
                               </div>
                           </div>
                           <div class="col-lg-4">
                               <div class="mb-3">
                                   <label class="form-label">Tanggal Masuk</label>
                                   <input type="date" class="form-control">
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="modal-footer">
                       <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                           Cancel
                       </a>
                       <a href="#" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                           <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                           <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                               <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                               <path d="M12 5l0 14" />
                               <path d="M5 12l14 0" />
                           </svg>
                           Create new report
                       </a>
                   </div>
               </div>
           </div>
       </div>

       <!-- Modal Detail -->
       <div class="modal modal-blur fade" id="modal-simple" tabindex="-1" role="dialog" aria-hidden="true">
           <div class="modal-dialog modal-dialog-centered" role="document">
               <div class="modal-content">
                   <div class="modal-header">
                       <h5 class="modal-title">Details</h5>
                       <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                   </div>
                   <div class="modal-body">
                       <div class="empty">
                           <div class="empty-img"><img src="./static/illustrations/undraw_quitting_time_dm8t.svg" height="128" alt="">
                           </div>
                           <p class="empty-title">Details for maintenance</p>
                           <p class="empty-subtitle text-secondary">
                               Sorry for the inconvenience but we’re performing some maintenance at the moment. We’ll be back online shortly!
                           </p>
                       </div>
                   </div>
                   <!-- <div class="modal-footer">
                       <button type="button" class="btn me-auto" data-bs-dismiss="modal">Close</button>
                       <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Save changes</button>
                   </div> -->
               </div>
           </div>
       </div>

       <!-- Modal Delete -->
       <div class="modal modal-blur fade" id="modal-danger" tabindex="-1" role="dialog" aria-hidden="true">
           <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
               <div class="modal-content">
                   <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                   <div class="modal-status bg-danger"></div>
                   <div class="modal-body text-center py-4">
                       <!-- Download SVG icon from http://tabler-icons.io/i/alert-triangle -->
                       <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                           <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                           <path d="M10.24 3.957l-8.422 14.06a1.989 1.989 0 0 0 1.7 2.983h16.845a1.989 1.989 0 0 0 1.7 -2.983l-8.423 -14.06a1.989 1.989 0 0 0 -3.4 0z" />
                           <path d="M12 9v4" />
                           <path d="M12 17h.01" />
                       </svg>
                       <h3>Yakin Mau Dihapus?</h3>
                       <div class="text-secondary">Data ... akan hilang akan hilang lhoo</div>
                   </div>
                   <div class="modal-footer">
                       <div class="w-100">
                           <div class="row">
                               <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                                       Gak Ah
                                   </a></div>
                               <div class="col"><a href="#" class="btn btn-danger w-100" data-bs-dismiss="modal">
                                       Yakin Lah
                                   </a></div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>

       <?= $this->endSection(); ?>
<?php

namespace App\Models;

use CodeIgniter\Model;

class m_admin extends Model
{
    public function data_karyawan()
    {
        return $this->db->table('karyawan')
            ->select("nama, 
                    jabatan, 
                    UPPER(CONCAT(
                        LEFT(nama, 1), 
                        IF(INSTR(nama, ' ') > 0, LEFT(SUBSTRING_INDEX(nama, ' ', -1), 1), '')
                    )) AS inisial")
            ->get()
            ->getResultArray();
    }

    public function tambahData($data)
    {
        return $this->db->table('karyawan')
                        ->insert($data);
    }
}

<?php

namespace App\Controllers;

use App\Models\m_admin;

class c_admin extends BaseController
{
    protected $adm;

    public function __construct()
    {
        $this->adm = new m_admin();
    }

    public function index()
    {
        // Ambil semua data karyawan
        $data = [
            'karyawan' => $this->adm->data_karyawan(),
        ];

        // Kirim data ke view
        return view('karyawan', $data);
    }

    public function tambahData()
    {

        // Simpan data baru
        $data = [
            'nama'      => $this->request->getPost('nama'),
            'jabatan'   => $this->request->getPost('jabatan'),
            'gaji'      => $this->request->getPost('gaji'),
            'tanggal_masuk' => $this->request->getPost('tgl_masuk'),
        ];

        $this->adm->tambahData($data);

        return redirect()->to('/karyawan');
    }
}

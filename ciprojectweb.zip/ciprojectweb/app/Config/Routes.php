<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/dashboard', 'Dashboard::index');
$routes->get('/karyawan', 'c_admin::index');
$routes->post('/tambahData', 'c_admin::tambahData');